package com.capgemini.payment.bean.Excep;

public class InvalidNameException extends Exception {
	public InvalidNameException() {
		// TODO Auto-generated constructor stub
		System.out.println("Exception occured");
	}

}
