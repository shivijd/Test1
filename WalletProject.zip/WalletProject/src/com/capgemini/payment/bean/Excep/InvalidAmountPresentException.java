package com.capgemini.payment.bean.Excep;

public class InvalidAmountPresentException extends Exception {

}
