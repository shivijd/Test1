package com.cg.productmgmt.exceptions;

@SuppressWarnings("serial")
public class ProductException extends Exception {

}
