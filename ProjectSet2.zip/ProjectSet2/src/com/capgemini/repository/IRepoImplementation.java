package com.capgemini.repository;

import java.util.HashMap;
import java.util.Map.Entry;

import com.capgemini.beans.Product;
import com.capgemini.util.DButil;

public class IRepoImplementation implements IRepoClass{
   HashMap<Integer,Product> map=(HashMap<Integer, Product>) DButil.getProducts();
	@Override
	public Product getProductDetails(int productCode) {
		for(Entry<Integer,Product>entry:map.entrySet())
			if(entry.getKey().equals(productCode))
				return entry.getValue();
		return null;
	}

}
