package com.capgemini.repository;

import com.capgemini.beans.Product;

public interface IRepoClass {
	Product getProductDetails(int productCode) ;
}
