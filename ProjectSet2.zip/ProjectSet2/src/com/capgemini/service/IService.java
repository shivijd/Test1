package com.capgemini.service;

import com.capgemini.beans.Product;

public interface IService {
	Product getProductDetails(int productCode) ;
}
