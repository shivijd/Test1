package com.capgemini.service;

import com.capgemini.beans.Product;
import com.capgemini.repository.IRepoClass;

public class ServiceImplementation implements IService {

	IRepoClass irepo;
	
	
	public ServiceImplementation(IRepoClass irepo) {
		super();
		this.irepo = irepo;
	}


	@Override
	public Product getProductDetails(int productCode) {
		Product product=irepo.getProductDetails(productCode);
		return product;
	}

}
