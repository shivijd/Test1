package com.capgemini.payment.bean.Excep;

public class InvalidPhoneNumberException extends Exception {

}
