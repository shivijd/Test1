package com.capgemini.payment.bean.Excep;

public class MobileNumberAlreadyExistException extends Exception {

}
